<?php

$to = 'jethwavaidik@gmail.com';

if (
  isset($_POST['name']) &&
  isset($_POST['email']) &&
  isset($_POST['subject']) &&
  isset($_POST['message'])
) {

  $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
  $email = htmlspecialchars($_POST['email'], ENT_QUOTES, 'UTF-8');
  $subject = htmlspecialchars($_POST['subject'], ENT_QUOTES, 'UTF-8');
  $message = htmlspecialchars($_POST['message'], ENT_QUOTES, 'UTF-8');

  $headers = "From: $name <$email>\r\n";
  $headers .= "Reply-To: $email\r\n";
  $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

  $full_message = "Name: $name\n";
  $full_message .= "Email: $email\n\n";
  $full_message .= "Message:\n$message";

  if (mail($to, $subject, $full_message, $headers)) {
    echo 'Message sent successfully!';
  } else {
    echo 'Error sending message.';
  }
} else {
  echo 'Error: All fields are required.';
}
